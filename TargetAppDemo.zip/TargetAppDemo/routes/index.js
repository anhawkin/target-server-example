var express = require('express');
var router = express.Router();

var request = require('request'),
randString = Math.floor(Math.random()*100000000).toString(),
randNum = Math.floor(Math.random()*1000000),
tntId = '',
stuffwoId = {
	url: 'https://mboxedge.tt.omtrdc.net/rest/v1/mbox/' + randString + '?client=adobedemogreg',
	method: 'POST',
	headers: {
		'content-type': 'application/json'
	},
	body: {
		'mbox' : 'node-app-visitorId-fetch'
	},
	json: true
};
// make a request to Target to set an ID
request(stuffwoId, function(error, response, body) {
	
	console.log(body);
	tntId = body.tntId;
	var stuffwId = {
	url: 'https://mboxedge.tt.omtrdc.net/rest/v1/mbox/' + randString + '?client=adobedemogreg',
	method: 'POST',
	headers: {
		'content-type': 'application/json'
	},
	body: {
		'mbox' : 'node-app-mbox',
		'tntId' : tntId,
		'mboxParameters' : {
      	'parameter1' : randNum
   		}
	},
	json: true	
}

/* GET home page with request to Target for content. */
router.get('/', function(req, res, next) {	
	request(stuffwId, function (error, response, body) {
  	if (!error && response.statusCode == 200) {
  		console.log(body) 
  		  res.render('index', { title: 'Target Server-Side Application Example',
  		  experience: body.content });
  		// Show the body for the response. 
  }
})	
});
});
module.exports = router;
